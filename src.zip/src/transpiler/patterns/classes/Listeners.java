package fr.blosky;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.Bukkit;
%imports%

public class Listeners implements Listener {

    %child_nodes%

}