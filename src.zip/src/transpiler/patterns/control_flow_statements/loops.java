%instruction% {
    %child_nodes%
}