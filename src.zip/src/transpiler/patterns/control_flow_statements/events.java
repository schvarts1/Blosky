@EventHandler
public void Event%ID%(final %instruction% event) {

    %child_nodes%

}
