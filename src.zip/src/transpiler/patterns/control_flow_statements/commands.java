%instruction% {

    %child_nodes%

}